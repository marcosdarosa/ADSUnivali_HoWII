import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welness-and-spa',
  templateUrl: './welness-and-spa.component.html',
  styleUrls: ['./welness-and-spa.component.css']
})
export class WelnessAndSpaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
